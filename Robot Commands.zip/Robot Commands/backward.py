import RPi.GPIO as GPIO
import time

GPIO.setmode(GPIO.BOARD)
GPIO.setup(7,GPIO.OUT)
GPIO.setup(11,GPIO.OUT)
GPIO.setup(13,GPIO.OUT)
GPIO.setup(15,GPIO.OUT)

#infite backward unless killed
while(1):
    GPIO.output(11,True) #Right motor backward
    GPIO.output(13,True) #Left motor backward

