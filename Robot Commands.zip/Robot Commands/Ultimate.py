from PIL import Image, ImageTk
import _tkinter
import tkinter
import RPi.GPIO as GPIO
import time

GPIO.setmode(GPIO.BOARD)
GPIO.setup(7,GPIO.OUT)
GPIO.setup(11,GPIO.OUT)
GPIO.setup(13,GPIO.OUT)
GPIO.setup(15,GPIO.OUT)






def forward():
    GPIO.output(11,False)
    GPIO.output(13,False)
    GPIO.output(7,True) #Right motor forward
    GPIO.output(15,True) #Left motor forward

def backward():
    GPIO.output(7,False)
    GPIO.output(15,False)
    GPIO.output(11,True) #Right motor backward
    GPIO.output(13,True) #Left motor backward

def left():
    GPIO.output(11,False)
    GPIO.output(15,False)
    GPIO.output(7,True) #Right motor forward
    GPIO.output(13,True) #Left motor backward

def right():
    GPIO.output(7,False)
    GPIO.output(13,False)
    GPIO.output(11,True) #Right motor backward
    GPIO.output(15,True) #Left motor forward


top = tkinter.Tk()
top.configure(bg='#091219')
btn_Forward = tkinter.Button(top, text ="Forward", command = forward, width = 24, bg="#081016", fg="#ffffff", bd = 2, highlightthickness=0)
btn_Backward = tkinter.Button(top, text ="Backward", command = backward, width = 24, bg="#081016", fg="#ffffff", bd = 2, highlightthickness=0)
btn_Left = tkinter.Button(top, text ="Left", command = left, width = 24, bg="#081016", fg="#ffffff", bd = 2, highlightthickness=0)
btn_Right = tkinter.Button(top, text ="Right", command = right, width = 24 , bg="#081016", fg="#ffffff", bd = 2, highlightthickness=0)

btn_Forward.pack()
btn_Backward.pack()
btn_Left.pack()
btn_Right.pack()

top.mainloop()